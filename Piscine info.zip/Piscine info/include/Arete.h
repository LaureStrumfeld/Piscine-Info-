#ifndef ARETE_H
#define ARETE_H
#include "string"


class Arete
{
    public:
        Arete();

    protected:

    private:
        Sommet* m_sommetDepart;
        Sommet* m_sommetArrivee;

};

#endif // ARETE_H
