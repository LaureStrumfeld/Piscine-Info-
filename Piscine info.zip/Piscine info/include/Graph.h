#ifndef GRAPH_H
#define GRAPH_H


class Graph
{
    public:
        Graph();
        virtual ~Graph();

    protected:

    private:
};

#endif // GRAPH_H
