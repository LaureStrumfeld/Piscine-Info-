#ifndef ANIMAUXSAVANE_H
#define ANIMAUXSAVANE_H


class AnimauxSavane
{
    public:
        AnimauxSavane();
        virtual ~AnimauxSavane();

    protected:

    private:
};

#endif // ANIMAUXSAVANE_H
