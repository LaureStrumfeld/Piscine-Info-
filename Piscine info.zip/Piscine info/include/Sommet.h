#ifndef SOMMET_H
#define SOMMET_H
#include "string"

class Sommet
{
    public:
        Sommet();

    protected:

    private:
        AnimalOcean* m_animalAssocie;

};

#endif // SOMMET_H
