#ifndef RESSOURCE_H
#define RESSOURCE_H


class Ressource
{
    public:
        Ressource();

    protected:

    private:
};

#endif // RESSOURCE_H
