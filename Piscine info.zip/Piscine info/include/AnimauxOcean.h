#ifndef ANIMAUXOCEAN_H
#define ANIMAUXOCEAN_H


class AnimauxOcean
{
    public:
        AnimauxOcean();
        virtual ~AnimauxOcean();

    protected:

    private:
};

#endif // ANIMAUXOCEAN_H
