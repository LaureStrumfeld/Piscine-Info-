#ifndef ANIMALSAVANE_H
#define ANIMALSAVANE_H
#include "string"


class AnimalSavane
{
    public:
        AnimalSavane();//constructeur par default
        AnimalSavane(string nom); //constructeur surcharge
        void AnimalSavane(std::string nom);

    protected:

    private:
};

#endif // ANIMALSAVANE_H
