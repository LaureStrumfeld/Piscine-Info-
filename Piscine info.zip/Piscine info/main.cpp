#include <iostream>
#include "AnimalAntarctic.h"
#include "AnimalSavane.h"
#include "AnimalOcean.h"
#include "Arete.h"
#include "Sommet.h"
#include "Ressource.h"
#include "Graph.h"


using namespace std;

int main()
{

    return 0;
}
