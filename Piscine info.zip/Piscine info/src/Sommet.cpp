#include "Sommet.h"

using namespace std;

Sommet::Sommet()
{
    //ctor
}

Sommet::~Sommet()
{
    //dtor
}

