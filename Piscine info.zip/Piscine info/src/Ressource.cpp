#include "Ressource.h"

Ressource::Ressource()
{
    //ctor
}

Ressource::~Ressource()
{
    //dtor
}
