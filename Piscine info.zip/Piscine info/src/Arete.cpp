#include "Arete.h"

using namespace std;


Arete::Arete()
{
    //ctor
}

Arete::~Arete()
{
    //dtor
}
